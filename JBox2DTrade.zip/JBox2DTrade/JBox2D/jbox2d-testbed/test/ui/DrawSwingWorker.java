package ui;

import java.util.List;

import javax.swing.SwingWorker;

public class DrawSwingWorker extends SwingWorker<Void, Object> {

	@Override
	protected Void doInBackground() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	protected void process(List<Object> lo){
		
	}
	

}
