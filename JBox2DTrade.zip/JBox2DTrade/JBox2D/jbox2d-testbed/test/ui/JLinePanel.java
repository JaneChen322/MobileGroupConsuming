package ui;

import javax.swing.JPanel;

public class JLinePanel extends JPanel {
	public JLinePanel(){
		
	}
}
