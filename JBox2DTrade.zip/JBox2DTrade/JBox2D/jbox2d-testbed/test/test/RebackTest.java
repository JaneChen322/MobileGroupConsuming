package test;

import org.jbox2d.testbed.framework.TestbedTest;

public class RebackTest extends TestbedTest {

	@Override
	public void initTest(boolean deserialized) {
		// TODO Auto-generated method stub

	}

	@Override
	public String getTestName() {
		// TODO Auto-generated method stub
		return "Reback Test";
	}

}
